import http.server
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

print("Serving at http://localhost:8001/parametric_temple.html")
http.server.HTTPServer(("", 8001), Handler).serve_forever()
