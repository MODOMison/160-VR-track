/* Parametric GLB Augmentor — drop an Infinigen .glb, modulate environment via 150+ sliders.
   Built for COGS160. Photoreal: ACES tonemap + sRGB + soft shadows + PMREM IBL + anisotropic textures. */

const THREE = AFRAME.THREE;

const P = {
  // Model controls
  modelScale: 1, modelRotY: 0, modelPosY: 0,
  modelAutoFit: true, fitToHall: 10,
  modelShadows: true, modelVisible: true,

  // Wall modifiers — applied to meshes in the loaded glb whose name matches wallPattern.
  // Multipliers (1.0 = no change). Bow/tilt/jag are additive offsets in meters.
  wallPattern: 'wall',
  wallHeight: 1.0, wallThickness: 1.0, wallBow: 0, wallTilt: 0, wallTopJag: 0,
  wallSegments: 12, wallColor: '#a8a392', wallRough: 0.9,

  // Water
  waterEnabled: false, waterLevel: -0.4, waterColor: '#2a4a52', waterMurk: 0.6,
  waterWaveAmp: 0.05, waterWaveFreq: 1.0, waterReflect: 0.4, waterFoam: 0.3,
  waterPadFactor: 1.3,

  // Lighting
  sunAzimuth: 60, sunElevation: 45, sunIntensity: 3.5, sunColor: '#fff2d0',
  ambientLevel: 0.6, ambientColor: '#a8b8c8',
  hemiIntensity: 0.8, hemiSky: '#aac0ff', hemiGround: '#4a3a28',
  envIntensity: 1.0, envPreset: 'studio',
  godRayCount: 0, godRayIntensity: 0.7, godRayWidth: 0.6,
  torchCount: 0, torchColor: '#ff9040', torchFlicker: 0.5, torchIntensity: 1.0,
  shadowSoft: 1.5,

  // Atmosphere
  fogDensity: 0.008, fogColor: '#7a8898', fogHeightFalloff: 0.5,
  dustDensity: 0, dustSize: 0.04, dustDrift: 0.1,
  bloomStrength: 0.0,

  // Sky / environment
  skyMode: 'gradient', skyTop: '#1a2030', skyBottom: '#3a4858',
  timeOfDay: 0.5, beyondWalls: 'forest',

  // Vegetation
  vineDensity: 0, vineLength: 1.4, vineSway: 0.3,
  mossSpecies: 'lichen', mossHue: '#4a6038',
  floorPlants: 0, floatingLeaves: 0,
  flowerDensity: 0, flowerColor: '#d0c060',

  // Props
  statueCount: 0, statueStyle: 'humanoid', statueDamage: 0.5,
  altar: false, sarcCount: 0,
  rubbleDensity: 0, columnPieces: 0,
  potteryDensity: 0, brazierCount: 0,
  bannerCount: 0, bannerColor: '#7a2030',

  // Decay applied to loaded model materials
  masterDecay: 0, crackDensity: 0, erosion: 0, colorFade: 0, bioGrowth: 0,
  modelRoughBias: 0, modelMetalBias: 0, modelEmissive: 0, modelTint: '#ffffff',

  // Post
  postFxEnabled: true,
  exposure: 1.2, contrast: 1.0, saturation: 1.0, tint: '#ffffff', vignette: 0.0,
  bloomThreshold: 0.85, bloomRadius: 1.0,
  fxaa: true, tonemapping: 'aces',

  // Camera / participant
  walkSpeed: 0.15, fov: 80, eyeHeight: 1.6, headBob: 0,
  locomotion: 'smooth',

  // Time
  dayNightSpeed: 0, waterRiseRate: 0,
  vegGrowthRate: 0, windStrength: 0.3,

  // VR / interaction
  physics: false, handModel: 'none',
  vrComfort: 0.4, ipdOffset: 0,

  // Experiment
  seed: 42, trialDuration: 60, stimDelay: 2,
  fixationVisible: false, variantLabel: true, showStats: true,
};

// --- seeded RNG ---
let _s = P.seed;
function srand(){ _s = (_s*9301+49297)%233280; return _s/233280; }
function reseed(s){ _s = (s|0) || 1; }
function lerp(a,b,t){ return a+(b-a)*t; }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

// --- runtime state ---
let loadedModel = null;        // THREE.Group from gltf-model
let modelMaterials = [];       // unique materials in loaded model
let modelBounds = null;        // THREE.Box3 (live, recomputed after scale)
let modelBaseBounds = null;    // bounds at scale=1 (for footprint calc)
let originalMatProps = new Map(); // material -> {color, roughness, metalness, emissive}
let autoFitScale = 1;          // base scale chosen by autoFit
let wallData = [];             // [{mesh, origGeo, axes:{thin,mid,long}, size, center}]
let envScene = null;
let envTexture = null;
let pmremGen = null;

// Effective bounds (model if loaded, otherwise procedural hall) — used by all builders
function getBounds() {
  if (loadedModel && modelBounds) {
    const size = modelBounds.getSize(new THREE.Vector3());
    return {
      W: Math.max(size.x, 8) * 1.4,
      L: Math.max(size.z, 8) * 1.4,
      H: Math.max(size.y, 4) * 1.2,
      cx: 0, cz: 0, floorY: 0,
    };
  }
  return {
    W: P.hallWidth * P.scale,
    L: P.hallLength * P.scale,
    H: P.wallHeight * P.scale,
    cx: 0, cz: 0, floorY: 0,
  };
}

// --- material cache ---
function stoneMat(opts={}) {
  const base = new THREE.Color(opts.color||P.wallColor);
  const m = new THREE.MeshStandardMaterial({
    color: base,
    roughness: clamp((opts.rough ?? P.wallRough), 0.05, 1.0),
    metalness: clamp((opts.metal ?? 0), 0, 1),
    flatShading: opts.flat || false,
    envMapIntensity: P.envIntensity,
  });
  return m;
}
function waterMat() {
  const c = new THREE.Color(P.waterColor);
  return new THREE.MeshStandardMaterial({
    color: c, transparent: true, opacity: clamp(0.4 + P.waterMurk*0.5, 0.3, 0.95),
    roughness: clamp(1.0 - P.waterReflect, 0.05, 1.0), metalness: 0.3,
    envMapIntensity: P.envIntensity,
  });
}

function clearChildren(el){
  while(el.firstChild) el.removeChild(el.firstChild);
  const obj = el.getObject3D('mesh');
  if (obj){
    obj.traverse(o=>{ if(o.geometry) o.geometry.dispose(); if(o.material) (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose()); });
    el.removeObject3D('mesh');
  }
}

// --- IBL: build a small procedurally-lit env scene, PMREM it, apply as scene.environment ---
function buildEnvScene(preset='studio') {
  const s = new THREE.Scene();
  const matE = (c, i=1) => new THREE.MeshBasicMaterial({color:new THREE.Color(c).multiplyScalar(i)});
  // ground
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40,40), matE(0x404040));
  floor.rotation.x = -Math.PI/2; s.add(floor);
  // ceiling soft fill
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(40,40), matE(0x808080, 1.2));
  ceil.position.y = 12; ceil.rotation.x = Math.PI/2; s.add(ceil);
  // key/fill/rim emitters depending on preset
  const presets = {
    studio:  [[ 8, 6, 0, 0xffffff, 2.5], [-6, 5, 4, 0x8ab0ff, 1.3], [ 0, 5,-8, 0xffe0c0, 1.0]],
    sunset:  [[ 8, 4, 4, 0xff9050, 3.0], [-8, 3,-2, 0x4060ff, 0.6], [ 0, 8, 0, 0xffe0a0, 0.8]],
    overcast:[[ 0,12, 0, 0xc8d0e0, 2.8], [ 6, 3, 6, 0xa0b0c0, 0.6], [-6, 3,-6, 0xa0b0c0, 0.6]],
    night:   [[ 0,10, 0, 0x6080c0, 0.6], [ 4, 2, 0, 0xff8030, 0.4], [-4, 2, 0, 0xff8030, 0.4]],
    cave:    [[ 0, 2, 4, 0xff7030, 1.0], [ 0, 8, 0, 0x202030, 0.1]],
  };
  const lights = presets[preset] || presets.studio;
  for (const [x,y,z, col, inten] of lights) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(3,1,3), matE(col, inten));
    m.position.set(x,y,z); s.add(m);
  }
  return s;
}

function regenerateEnv() {
  const sceneEl = document.querySelector('a-scene');
  if (!sceneEl.renderer) return;
  if (!pmremGen) pmremGen = new THREE.PMREMGenerator(sceneEl.renderer);
  if (envTexture) envTexture.dispose();
  envScene = buildEnvScene(P.envPreset);
  envTexture = pmremGen.fromScene(envScene, 0.04).texture;
  sceneEl.object3D.environment = envTexture;
  // re-apply intensity to all materials
  sceneEl.object3D.traverse(o => {
    if (o.isMesh && o.material && 'envMapIntensity' in o.material) {
      o.material.envMapIntensity = P.envIntensity;
      o.material.needsUpdate = true;
    }
  });
}

// --- renderer photoreal setup ---
function configureRenderer() {
  const sceneEl = document.querySelector('a-scene');
  const r = sceneEl.renderer;
  if (!r) return;
  const TM = {aces:THREE.ACESFilmicToneMapping, reinhard:THREE.ReinhardToneMapping, cineon:THREE.CineonToneMapping, linear:THREE.LinearToneMapping, none:THREE.NoToneMapping};
  r.toneMapping = TM[P.tonemapping] || THREE.ACESFilmicToneMapping;
  r.toneMappingExposure = P.exposure;
  if ('outputColorSpace' in r) r.outputColorSpace = THREE.SRGBColorSpace;
  else r.outputEncoding = THREE.sRGBEncoding;
  r.shadowMap.enabled = true;
  r.shadowMap.type = THREE.PCFSoftShadowMap;
  r.physicallyCorrectLights = true;
}

// --- Post-FX pipeline (inline EffectComposer) ---
// Pipeline: scene → rtScene → bright-extract → 2-pass Gaussian blur → composite (bloom+grade+vignette+fxaa) → screen
const VERT_QUAD = `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.0,1.0); }`;
const FRAG_BRIGHT = `
  uniform sampler2D tDiffuse; uniform float uThreshold; varying vec2 vUv;
  void main(){
    vec4 c = texture2D(tDiffuse, vUv);
    float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    float k = max(0.0, l - uThreshold);
    gl_FragColor = vec4(c.rgb * k, 1.0);
  }`;
const FRAG_BLUR = `
  uniform sampler2D tDiffuse; uniform vec2 uDir; uniform vec2 uRes; uniform float uRadius; varying vec2 vUv;
  void main(){
    vec2 off = uDir / uRes * uRadius;
    vec3 c = vec3(0.0);
    c += texture2D(tDiffuse, vUv - off*4.0).rgb * 0.05;
    c += texture2D(tDiffuse, vUv - off*3.0).rgb * 0.09;
    c += texture2D(tDiffuse, vUv - off*2.0).rgb * 0.12;
    c += texture2D(tDiffuse, vUv - off    ).rgb * 0.15;
    c += texture2D(tDiffuse, vUv          ).rgb * 0.18;
    c += texture2D(tDiffuse, vUv + off    ).rgb * 0.15;
    c += texture2D(tDiffuse, vUv + off*2.0).rgb * 0.12;
    c += texture2D(tDiffuse, vUv + off*3.0).rgb * 0.09;
    c += texture2D(tDiffuse, vUv + off*4.0).rgb * 0.05;
    gl_FragColor = vec4(c, 1.0);
  }`;
const FRAG_COMPOSITE = `
  uniform sampler2D tScene; uniform sampler2D tBloom;
  uniform float uBloom, uContrast, uSaturation, uVignette;
  uniform vec3 uTint;
  uniform float uFxaa; uniform vec2 uRes;
  varying vec2 vUv;
  // tiny FXAA-lite (1.0/4.0/8.0 thresholds, single pass)
  vec3 fxaa(sampler2D tex, vec2 uv, vec2 res){
    vec2 px = 1.0 / res;
    vec3 rgbNW = texture2D(tex, uv + vec2(-1.0,-1.0)*px).rgb;
    vec3 rgbNE = texture2D(tex, uv + vec2( 1.0,-1.0)*px).rgb;
    vec3 rgbSW = texture2D(tex, uv + vec2(-1.0, 1.0)*px).rgb;
    vec3 rgbSE = texture2D(tex, uv + vec2( 1.0, 1.0)*px).rgb;
    vec3 rgbM  = texture2D(tex, uv).rgb;
    vec3 luma  = vec3(0.299, 0.587, 0.114);
    float lNW = dot(rgbNW, luma); float lNE = dot(rgbNE, luma);
    float lSW = dot(rgbSW, luma); float lSE = dot(rgbSE, luma);
    float lM  = dot(rgbM,  luma);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.25 * (1.0/8.0), 1.0/128.0);
    float rcpDirMin = 1.0/(min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * px;
    vec3 rgbA = 0.5*(texture2D(tex, uv + dir*(1.0/3.0 - 0.5)).rgb +
                     texture2D(tex, uv + dir*(2.0/3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA*0.5 + 0.25*(texture2D(tex, uv + dir*-0.5).rgb +
                                  texture2D(tex, uv + dir* 0.5).rgb);
    float lB = dot(rgbB, luma);
    return (lB < lMin || lB > lMax) ? rgbA : rgbB;
  }
  void main(){
    vec3 col = (uFxaa > 0.5) ? fxaa(tScene, vUv, uRes) : texture2D(tScene, vUv).rgb;
    vec3 blm = texture2D(tBloom, vUv).rgb;
    col += blm * uBloom;
    col = (col - 0.5) * uContrast + 0.5;
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, uSaturation);
    col *= uTint;
    vec2 d = vUv - 0.5; float v = 1.0 - dot(d,d) * uVignette * 2.5;
    col *= clamp(v, 0.0, 1.0);
    gl_FragColor = vec4(col, 1.0);
  }`;

class PostFX {
  constructor(renderer, scene, camera, origRender) {
    this.r = renderer; this.s = scene; this.c = camera; this.origRender = origRender;
    this._size = new THREE.Vector2();
    renderer.getSize(this._size);
    const px = renderer.getPixelRatio();
    const W = Math.max(1, Math.floor(this._size.x * px));
    const H = Math.max(1, Math.floor(this._size.y * px));
    const rtOpts = {
      minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
      type: (renderer.capabilities.isWebGL2 ? THREE.HalfFloatType : THREE.UnsignedByteType),
      format: THREE.RGBAFormat,
    };
    this.rtScene = new THREE.WebGLRenderTarget(W, H, rtOpts);
    this.rtBright = new THREE.WebGLRenderTarget(W/2|0, H/2|0, rtOpts);
    this.rtBlurA  = new THREE.WebGLRenderTarget(W/2|0, H/2|0, rtOpts);
    this.rtBlurB  = new THREE.WebGLRenderTarget(W/2|0, H/2|0, rtOpts);

    this.qScene = new THREE.Scene();
    this.qCam = new THREE.OrthographicCamera(-1,1,1,-1,0,1);
    const geo = new THREE.PlaneGeometry(2,2);

    this.matBright = new THREE.ShaderMaterial({
      vertexShader: VERT_QUAD, fragmentShader: FRAG_BRIGHT,
      uniforms: { tDiffuse:{value:null}, uThreshold:{value:0.85} },
    });
    this.matBlur = new THREE.ShaderMaterial({
      vertexShader: VERT_QUAD, fragmentShader: FRAG_BLUR,
      uniforms: { tDiffuse:{value:null}, uDir:{value:new THREE.Vector2(1,0)},
                  uRes:{value:new THREE.Vector2(W/2, H/2)}, uRadius:{value:1.0} },
    });
    this.matComp = new THREE.ShaderMaterial({
      vertexShader: VERT_QUAD, fragmentShader: FRAG_COMPOSITE,
      uniforms: {
        tScene:{value:null}, tBloom:{value:null},
        uBloom:{value:0.0}, uContrast:{value:1.0}, uSaturation:{value:1.0},
        uTint:{value:new THREE.Color(1,1,1)}, uVignette:{value:0.0},
        uFxaa:{value:1.0}, uRes:{value:new THREE.Vector2(W, H)},
      },
    });
    this.quad = new THREE.Mesh(geo);
    this.qScene.add(this.quad);
  }

  setSize(w, h) {
    const px = this.r.getPixelRatio();
    const W = Math.max(1, Math.floor(w * px));
    const H = Math.max(1, Math.floor(h * px));
    this._size.set(w, h);
    this.rtScene.setSize(W, H);
    this.rtBright.setSize(W/2|0, H/2|0);
    this.rtBlurA.setSize(W/2|0, H/2|0);
    this.rtBlurB.setSize(W/2|0, H/2|0);
    this.matBlur.uniforms.uRes.value.set(W/2|0, H/2|0);
    this.matComp.uniforms.uRes.value.set(W, H);
  }

  render() {
    const r = this.r;
    // 1. scene → rtScene (uses original render so it sees lights, shadows, env)
    r.setRenderTarget(this.rtScene);
    r.clear();
    this.origRender(this.s, this.c);

    // 2. bright extract
    this.matBright.uniforms.tDiffuse.value = this.rtScene.texture;
    this.matBright.uniforms.uThreshold.value = P.bloomThreshold;
    this.quad.material = this.matBright;
    r.setRenderTarget(this.rtBright);
    r.clear();
    this.origRender(this.qScene, this.qCam);

    // 3. blur horizontal then vertical
    this.matBlur.uniforms.uRadius.value = P.bloomRadius;
    this.matBlur.uniforms.tDiffuse.value = this.rtBright.texture;
    this.matBlur.uniforms.uDir.value.set(1, 0);
    this.quad.material = this.matBlur;
    r.setRenderTarget(this.rtBlurA);
    r.clear();
    this.origRender(this.qScene, this.qCam);
    this.matBlur.uniforms.tDiffuse.value = this.rtBlurA.texture;
    this.matBlur.uniforms.uDir.value.set(0, 1);
    r.setRenderTarget(this.rtBlurB);
    r.clear();
    this.origRender(this.qScene, this.qCam);

    // 4. composite to screen
    const u = this.matComp.uniforms;
    u.tScene.value = this.rtScene.texture;
    u.tBloom.value = this.rtBlurB.texture;
    u.uBloom.value = P.bloomStrength;
    u.uContrast.value = P.contrast;
    u.uSaturation.value = P.saturation;
    u.uTint.value.set(P.tint);
    u.uVignette.value = P.vignette;
    u.uFxaa.value = P.fxaa ? 1.0 : 0.0;
    this.quad.material = this.matComp;
    r.setRenderTarget(null);
    this.origRender(this.qScene, this.qCam);
  }
}

let postFx = null;
let _renderHijacked = false;
function setupPostFx() {
  const sceneEl = document.querySelector('a-scene');
  const r = sceneEl.renderer;
  if (!r || _renderHijacked) return;
  const origRender = r.render.bind(r);
  postFx = new PostFX(r, sceneEl.object3D, sceneEl.camera, origRender);
  let busy = false;
  r.render = function(scn, cam) {
    // pass-through in VR (post-FX + WebXR is non-trivial), or when disabled, or when re-entering recursively
    if (busy || r.xr.isPresenting || !P.postFxEnabled) return origRender(scn, cam);
    // pass-through if A-frame called this with a scene other than our main scene
    // (e.g. screenshot or sub-render). PostFx always uses the registered scene.
    if (scn !== sceneEl.object3D) return origRender(scn, cam);
    busy = true;
    try { postFx.render(); } finally { busy = false; }
  };
  _renderHijacked = true;

  const onResize = () => {
    const sz = new THREE.Vector2();
    r.getSize(sz);
    if (sz.x > 0 && sz.y > 0) postFx.setSize(sz.x, sz.y);
  };
  window.addEventListener('resize', onResize);
  setTimeout(onResize, 0);
  console.log('[glb] post-fx pipeline active');
}

// --- glTF loading ---
function loadGLBFile(file) {
  const url = URL.createObjectURL(file);
  loadGLBFromUrl(url, file.name, file.size);
}

function loadGLBFromUrl(url, name, size) {
  const el = document.getElementById('loaded-model');
  if (el.getAttribute('gltf-model')) el.removeAttribute('gltf-model');
  el.addEventListener('model-loaded', onModelLoaded, {once: true});
  el.addEventListener('model-error', (e) => {
    console.error('Model load error:', e.detail);
    document.getElementById('stat').textContent = 'load error: ' + ((e.detail && e.detail.src) || 'unknown');
  }, {once: true});
  el.setAttribute('gltf-model', url);
  const sizeStr = size ? ' (' + (size/1024/1024).toFixed(2) + ' MB)' : '';
  document.getElementById('stat').textContent = 'loading ' + (name||url) + sizeStr + '…';
  const dp = document.getElementById('drop-prompt');
  if (dp) dp.style.display = 'none';
}

function onModelLoaded(e) {
  const model = e.detail.model;
  loadedModel = model;

  // reset transform
  model.scale.setScalar(1);
  model.rotation.set(0,0,0);
  model.position.set(0,0,0);

  // base bounds at scale=1
  modelBaseBounds = new THREE.Box3().setFromObject(model);
  const baseSize = modelBaseBounds.getSize(new THREE.Vector3());

  // pick autoFit scale (P.modelScale acts as a multiplier on top)
  if (P.modelAutoFit) {
    const maxDim = Math.max(baseSize.x, baseSize.y, baseSize.z, 0.001);
    autoFitScale = P.fitToHall / maxDim;
  } else {
    autoFitScale = 1;
  }

  // walk materials + meshes
  modelMaterials = [];
  originalMatProps.clear();
  const sceneEl = document.querySelector('a-scene');
  const maxAniso = sceneEl.renderer ? sceneEl.renderer.capabilities.getMaxAnisotropy() : 1;
  let meshCount = 0;
  const matTypes = {};
  model.traverse(o => {
    if (o.isMesh) {
      meshCount++;
      if (P.modelShadows) { o.castShadow = true; o.receiveShadow = true; }
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) {
        if (!m) continue;
        matTypes[m.type] = (matTypes[m.type]||0)+1;
        // upgrade Basic/Lambert/Phong to Standard so lighting + IBL actually affect them
        if (m.type === 'MeshBasicMaterial' || m.type === 'MeshLambertMaterial' || m.type === 'MeshPhongMaterial') {
          const upgraded = new THREE.MeshStandardMaterial({
            color: m.color ? m.color.clone() : 0xffffff,
            map: m.map || null,
            transparent: m.transparent || false,
            opacity: m.opacity ?? 1,
            side: m.side,
            name: m.name || '',
            roughness: 0.85,
            metalness: 0.0,
          });
          if (Array.isArray(o.material)) {
            const idx = o.material.indexOf(m);
            o.material[idx] = upgraded;
          } else {
            o.material = upgraded;
          }
          // replace reference for the rest of the loop
          // (note: we continue using `m` below but push the upgraded one)
          const mm = upgraded;
          if (!modelMaterials.includes(mm)) modelMaterials.push(mm);
          if ('envMapIntensity' in mm) mm.envMapIntensity = P.envIntensity;
          originalMatProps.set(mm, {
            color: mm.color.clone(),
            roughness: mm.roughness,
            metalness: mm.metalness,
            emissive: mm.emissive ? mm.emissive.clone() : null,
            vertexColors: mm.vertexColors || false,
          });
          continue;
        }
        if (!modelMaterials.includes(m)) {
          modelMaterials.push(m);
          if ('envMapIntensity' in m) m.envMapIntensity = P.envIntensity;
          originalMatProps.set(m, {
            color: m.color ? m.color.clone() : null,
            roughness: m.roughness ?? 0.5,
            metalness: m.metalness ?? 0,
            emissive: m.emissive ? m.emissive.clone() : null,
            vertexColors: m.vertexColors || false,
          });
          for (const key of ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap']) {
            const tex = m[key];
            if (tex && tex.anisotropy !== undefined) {
              tex.anisotropy = maxAniso;
              tex.needsUpdate = true;
            }
          }
        }
      }
    }
  });

  console.log('[glb] loaded:', {meshes: meshCount, materials: modelMaterials.length, matTypes,
    baseSize: baseSize.toArray().map(v=>v.toFixed(2)), autoFitScale: autoFitScale.toFixed(3)});

  buildMaterialPanel();
  applyTransform();   // applies scale, rotation, grounding
  detectWalls();      // identify wall meshes + cache deformable geo
  rebuildAll();

  const sz = modelBounds ? modelBounds.getSize(new THREE.Vector3()) : baseSize;
  document.getElementById('stat').textContent =
    `loaded · ${meshCount} meshes · ${modelMaterials.length} mats · ${sz.x.toFixed(1)}×${sz.y.toFixed(1)}×${sz.z.toFixed(1)}m`;
}

function clearModel() {
  const el = document.getElementById('loaded-model');
  if (el.getAttribute('gltf-model')) el.removeAttribute('gltf-model');
  loadedModel = null;
  modelMaterials = [];
  modelBounds = null;
  originalMatProps.clear();
  buildMaterialPanel();
  rebuildAll();
  document.getElementById('stat').textContent = 'drop a .glb file anywhere to load';
  const dp = document.getElementById('drop-prompt'); if (dp) dp.style.display = 'block';
}

// --- detect walls in the loaded glb + cache subdivided geometry for deformation ---
function detectWalls() {
  wallData = [];
  if (!loadedModel) return;
  let pattern;
  try { pattern = new RegExp(P.wallPattern || 'wall', 'i'); }
  catch(e) { pattern = /wall/i; }
  const seg = Math.max(1, Math.floor(P.wallSegments));
  loadedModel.traverse(o => {
    if (!o.isMesh || !o.name) return;
    if (!pattern.test(o.name)) return;
    if (!o.geometry || !o.geometry.attributes || !o.geometry.attributes.position) return;
    o.geometry.computeBoundingBox();
    const bb = o.geometry.boundingBox;
    if (!bb) return;
    const sz = bb.getSize(new THREE.Vector3());
    const ctr = bb.getCenter(new THREE.Vector3());
    if (sz.x < 0.001 || sz.y < 0.001 || sz.z < 0.001) return;
    // identify axes: smallest=thin (thickness), middle=mid (height usually), largest=long
    const order = ['x','y','z'].sort((a,b)=>sz[a]-sz[b]);
    const thin = order[0], mid = order[1], long = order[2];
    // build subdivided box of the same size — only the long axis needs many segments for bow
    const segMap = {x:1, y:1, z:1};
    segMap[long] = seg;
    segMap[mid]  = 8;     // a few for tilt/jag falloff
    segMap[thin] = 1;
    const newGeo = new THREE.BoxGeometry(sz.x, sz.y, sz.z, segMap.x, segMap.y, segMap.z);
    if (Math.abs(ctr.x)+Math.abs(ctr.y)+Math.abs(ctr.z) > 0.001) {
      newGeo.translate(ctr.x, ctr.y, ctr.z);
    }
    wallData.push({
      mesh: o,
      origGeo: newGeo.clone(),
      axes: {thin, mid, long},
      size: {x:sz.x, y:sz.y, z:sz.z},
      center: {x:ctr.x, y:ctr.y, z:ctr.z},
    });
    o.geometry.dispose();
    o.geometry = newGeo;
    // force double-sided so wall is visible from either face (our subdivided box has
    // outward-facing normals; the original glb wall might have had inward normals)
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    for (const m of mats) if (m) m.side = THREE.DoubleSide;
  });
  console.log(`[walls] detected ${wallData.length} wall meshes from pattern /${P.wallPattern}/i`);
}

function applyWallDeform() {
  if (wallData.length === 0) return;
  for (const w of wallData) {
    const geo = w.origGeo.clone();
    const pos = geo.attributes.position;
    const arr = pos.array;
    const {thin, mid, long} = w.axes;
    const sz = w.size, ctr = w.center;
    const baseMid = ctr[mid] - sz[mid]/2;
    for (let i = 0; i < pos.count; i++) {
      const idx = i*3;
      const v = {x: arr[idx], y: arr[idx+1], z: arr[idx+2]};
      const tLong = (v[long] - ctr[long]) / sz[long];
      const tMid  = (v[mid]  - ctr[mid])  / sz[mid];
      // bow: sin curve peaks at center along long, displaces along thin, falls off at top/bottom
      const bowFactor = Math.sin((tLong + 0.5) * Math.PI);
      const heightFactor = 1 - Math.abs(tMid) * 2;
      v[thin] += bowFactor * P.wallBow * heightFactor;
      // tilt: shift along thin proportional to mid height
      v[thin] += (tMid + 0.5) * P.wallTilt;
      // top jag: deterministic hash noise on top edge
      if (tMid > 0.35 && P.wallTopJag > 0) {
        const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
        const noise = (s - Math.floor(s)) - 0.5;
        v[mid] += noise * P.wallTopJag * (tMid - 0.35) * 2.5;
      }
      // height multiplier — scale from base (so wall grows up)
      v[mid] = baseMid + (v[mid] - baseMid) * P.wallHeight;
      // thickness multiplier — scale around center
      v[thin] = ctr[thin] + (v[thin] - ctr[thin]) * P.wallThickness;
      arr[idx]   = v.x;
      arr[idx+1] = v.y;
      arr[idx+2] = v.z;
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    w.mesh.geometry.dispose();
    w.mesh.geometry = geo;
  }
}

function buildHall() { /* no-op — walls are loaded from glb and deformed in place */ }

// keep original procedural-hall code below for reference (unused)
function _buildHallProc_unused() {
  const el = document.getElementById('hall');
  clearChildren(el);
  if (!P.procHall) return;
  reseed(P.seed);
  const group = new THREE.Group();
  const b = getBounds();
  // When a model is loaded, b.W/L already have 1.4x padding. Multiply by procHallPad
  // so walls sit clearly OUTSIDE the loaded model (default 1.6 = 12% outside model bounds).
  // When no model, b.W = P.hallWidth * P.scale, procHallPad scales hall size directly.
  const W = (b.W / 1.4) * P.procHallPad;
  const L = (b.L / 1.4) * P.procHallPad;
  // hall height = max(wallHeight, model height + extra) so it always rises above loaded model
  const modelH = loadedModel ? (b.H / 1.2) : 0;
  const H = Math.max(P.wallHeight * P.scale, modelH + P.procHallExtraH);
  const T = P.wallThickness;

  if (P.floorVisible) {
    const fGeo = new THREE.PlaneGeometry(W*1.4, L*1.4, 32, 32);
    const fPos = fGeo.attributes.position;
    for(let i=0;i<fPos.count;i++) fPos.setZ(i, (srand()-0.5) * P.floorUnevenness * 2);
    fGeo.computeVertexNormals();
    const fMat = stoneMat({color:P.floorColor, rough:clamp(0.95 - P.floorWet*0.4, 0.1, 1)});
    const floor = new THREE.Mesh(fGeo, fMat);
    floor.rotation.x = -Math.PI/2;
    floor.receiveShadow = true;
    group.add(floor);
  }

  const wallY = H/2;
  const longWall = (xSign)=>{
    const wGeo = new THREE.BoxGeometry(T, H, L+T*2, 1, 8, P.wallSegments);
    const pos = wGeo.attributes.position;
    for(let i=0;i<pos.count;i++){
      const z = pos.getZ(i), y = pos.getY(i);
      const bowAmt = Math.sin((z/L+0.5)*Math.PI) * P.wallBow * (1 - Math.abs(y)/(H/2));
      pos.setX(i, pos.getX(i) - bowAmt*xSign);
      pos.setX(i, pos.getX(i) - (y/H + 0.5) * P.wallTilt * xSign);
      if (y > H*0.4) pos.setY(i, y - srand()*P.wallTopJag);
    }
    wGeo.computeVertexNormals();
    const m = stoneMat({color:P.wallColor, rough:P.wallRough});
    m.side = THREE.DoubleSide;
    const wall = new THREE.Mesh(wGeo, m);
    wall.position.set(xSign*(W/2 + T/2), wallY, 0);
    wall.castShadow = wall.receiveShadow = true;
    return wall;
  };
  group.add(longWall(1)); group.add(longWall(-1));

  // short walls (front/back caps) — closes off the hall so it's a real enclosed space
  const shortWall = (zSign)=>{
    const wGeo = new THREE.BoxGeometry(W, H, T, 4, 8, 1);
    const m = stoneMat({color:P.wallColor, rough:P.wallRough});
    m.side = THREE.DoubleSide;
    const wall = new THREE.Mesh(wGeo, m);
    wall.position.set(0, wallY, zSign*(L/2 + T/2));
    wall.castShadow = wall.receiveShadow = true;
    return wall;
  };
  group.add(shortWall(1)); group.add(shortWall(-1));

  // pillars
  if (P.pillarCount > 0) {
    const pillarMat = stoneMat({color:P.pillarColor, rough:0.85});
    const pH = H*0.95;
    for(let side=0; side<2; side++){
      const z = (side===0 ? 1 : -1) * (W/2 - P.pillarInset);
      for(let i=0;i<P.pillarCount;i++){
        const x = lerp(-L/2 + P.pillarInset, L/2 - P.pillarInset, i/(P.pillarCount-1 || 1));
        const r = P.pillarRadius * (1 + (srand()-0.5)*P.pillarAsym);
        let segs = 16;
        if (P.pillarStyle==='square') segs = 4;
        else if (P.pillarStyle==='smooth') segs = 32;
        const pGeo = new THREE.CylinderGeometry(r*0.85, r, pH * (1 - srand()*P.pillarDamage*0.4), segs, 8);
        const pm = new THREE.Mesh(pGeo, pillarMat);
        pm.position.set(x, pH/2, z);
        pm.rotation.x = (srand()-0.5) * P.pillarLean;
        pm.rotation.z = (srand()-0.5) * P.pillarLean;
        pm.castShadow = pm.receiveShadow = true;
        group.add(pm);
      }
    }
  }

  // ceiling
  if (P.vaultStyle === 'barrel'){
    const radius = W/2;
    const vGeo = new THREE.CylinderGeometry(radius, radius, L, 32, 4, true, 0, Math.PI);
    const vPos = vGeo.attributes.position;
    for(let i=0;i<vPos.count;i++){
      if (srand() < P.ceilingCollapse*0.15) vPos.setY(i, vPos.getY(i) + 2 + srand()*3);
    }
    vGeo.computeVertexNormals();
    const vMat = stoneMat({color:P.ceilingColor, rough:0.95});
    vMat.side = THREE.DoubleSide;
    const vault = new THREE.Mesh(vGeo, vMat);
    vault.position.set(0, H, 0);
    vault.rotation.x = Math.PI/2;
    vault.rotation.y = Math.PI;
    vault.castShadow = vault.receiveShadow = true;
    group.add(vault);
  } else if (P.vaultStyle === 'flat'){
    const cGeo = new THREE.PlaneGeometry(W, L, 8, 16);
    const cMat = stoneMat({color:P.ceilingColor});
    cMat.side = THREE.DoubleSide;
    const ceil = new THREE.Mesh(cGeo, cMat);
    ceil.position.y = H; ceil.rotation.x = Math.PI/2;
    group.add(ceil);
  }

  el.setObject3D('mesh', group);
}

function buildWater(){
  const el = document.getElementById('water');
  clearChildren(el);
  if (!P.waterEnabled) return;
  const b = getBounds();
  const g = new THREE.PlaneGeometry(b.W*P.waterPadFactor, b.L*P.waterPadFactor, 40, 40);
  const water = new THREE.Mesh(g, waterMat());
  water.rotation.x = -Math.PI/2;
  water.position.y = P.waterLevel;
  water.userData.isWater = true;
  water.receiveShadow = true;
  el.setObject3D('mesh', water);
}

function buildProps(){
  reseed(P.seed + 7);
  const el = document.getElementById('props');
  clearChildren(el);
  const group = new THREE.Group();
  const b = getBounds();
  const W = b.W, L = b.L;
  const rubMat = stoneMat({color:'#7a7060', flat:true});

  const rubN = Math.floor(P.rubbleDensity * 80);
  for(let i=0;i<rubN;i++){
    const s = 0.2 + srand()*0.6;
    const g = new THREE.BoxGeometry(s, s*0.7, s);
    const m = new THREE.Mesh(g, rubMat);
    // place around the model, not in it
    const r = 0.35 + srand()*0.55;
    const ang = srand()*Math.PI*2;
    m.position.set(Math.cos(ang)*W*r*0.5, s*0.35, Math.sin(ang)*L*r*0.5);
    m.rotation.y = srand()*Math.PI;
    m.castShadow = true;
    group.add(m);
  }

  for(let i=0;i<P.columnPieces;i++){
    const r = 0.4 + srand()*0.2;
    const g = new THREE.CylinderGeometry(r, r, 0.8 + srand()*0.6, 12);
    const m = new THREE.Mesh(g, stoneMat({color:P.pillarColor}));
    m.position.set((srand()-0.5)*W*0.85, 0.4, (srand()-0.5)*L*0.85);
    m.rotation.z = Math.PI/2;
    m.rotation.y = srand()*Math.PI;
    m.castShadow = true;
    group.add(m);
  }

  for(let i=0;i<P.statueCount;i++){
    const x = (srand()-0.5)*W*0.6;
    const z = (srand()-0.5)*L*0.6;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.3,0.4,2.0,8), stoneMat({color:'#c0b8a0'}));
    body.position.set(x, 1.0, z); body.castShadow=true; group.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.35*(1-P.statueDamage*0.5),12,12), stoneMat({color:'#c0b8a0'}));
    head.position.set(x, 2.2, z); head.castShadow=true;
    if (P.statueDamage < 0.7) group.add(head);
    const base = new THREE.Mesh(new THREE.BoxGeometry(1,0.3,1), stoneMat({color:P.pillarColor}));
    base.position.set(x, 0.15, z); group.add(base);
  }

  if (P.altar){
    const a = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.0, 1.2), stoneMat({color:'#9a8870'}));
    a.position.set(0, 0.5, -L/2 + 2); a.castShadow = true; group.add(a);
  }

  for(let i=0;i<P.brazierCount;i++){
    const x = ((i%2)?1:-1) * (W/2 - 1.0);
    const z = lerp(-L/2 + 2, L/2 - 2, Math.floor(i/2)/(Math.max(1,Math.ceil(P.brazierCount/2)-1)));
    const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.35,0.2,0.3,12), stoneMat({color:'#2a2018'}));
    bowl.position.set(x, 1.2, z); group.add(bowl);
    const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.12,1.0,8), stoneMat({color:'#2a2018'}));
    stand.position.set(x, 0.5, z); group.add(stand);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.6, 8), new THREE.MeshBasicMaterial({color:P.torchColor, transparent:true, opacity:0.85}));
    flame.position.set(x, 1.55, z); flame.userData.flicker = true; group.add(flame);
  }

  el.setObject3D('mesh', group);
}

function buildVeg(){
  reseed(P.seed + 13);
  const el = document.getElementById('veg');
  clearChildren(el);
  const group = new THREE.Group();
  const b = getBounds();
  const W = b.W, L = b.L, H = b.H;

  const vN = Math.floor(P.vineDensity * 60);
  const vineMat = new THREE.MeshStandardMaterial({color:P.mossHue, roughness:1, envMapIntensity:P.envIntensity});
  for(let i=0;i<vN;i++){
    const len = P.vineLength * (0.6 + srand()*0.8);
    const g = new THREE.CylinderGeometry(0.02, 0.04, len, 4);
    const m = new THREE.Mesh(g, vineMat);
    const side = srand()<0.5?1:-1;
    m.position.set((srand()-0.5)*W*0.95, H - len/2, side*(L/2 - 0.5) + (srand()-0.5));
    if (srand()<0.5){
      m.position.set(side*(W/2 - 0.5), H - len/2, (srand()-0.5)*L*0.95);
    }
    m.userData.sway = (srand()-0.5)*P.vineSway;
    group.add(m);
  }

  const fpN = Math.floor(P.floorPlants * 60);
  const plantMat = new THREE.MeshStandardMaterial({color:'#3a5828', roughness:1, envMapIntensity:P.envIntensity});
  for(let i=0;i<fpN;i++){
    const g = new THREE.ConeGeometry(0.15, 0.4, 6);
    const m = new THREE.Mesh(g, plantMat);
    m.position.set((srand()-0.5)*W*0.95, 0.2, (srand()-0.5)*L*0.95);
    group.add(m);
  }

  if (P.waterEnabled && P.floatingLeaves > 0){
    const lfN = Math.floor(P.floatingLeaves * 40);
    const lMat = new THREE.MeshStandardMaterial({color:'#5a4a28', roughness:1, side:THREE.DoubleSide, envMapIntensity:P.envIntensity});
    for(let i=0;i<lfN;i++){
      const g = new THREE.CircleGeometry(0.15 + srand()*0.15, 6);
      const m = new THREE.Mesh(g, lMat);
      m.rotation.x = -Math.PI/2;
      m.position.set((srand()-0.5)*W*0.9, P.waterLevel + 0.02, (srand()-0.5)*L*0.9);
      group.add(m);
    }
  }

  el.setObject3D('mesh', group);
}

function buildTorches(){
  const el = document.getElementById('torches');
  clearChildren(el);
  const group = new THREE.Group();
  const b = getBounds();
  const W = b.W, L = b.L;
  for(let i=0;i<P.torchCount;i++){
    const x = ((i%2)?1:-1) * (W/2 - 0.6);
    const z = lerp(-L/2 + 2, L/2 - 2, Math.floor(i/2)/(Math.max(1,Math.ceil(P.torchCount/2)-1)));
    const light = new THREE.PointLight(P.torchColor, P.torchIntensity, 12, 2);
    light.position.set(x, 2.5, z);
    light.castShadow = true;
    light.userData.baseIntensity = P.torchIntensity;
    light.userData.flicker = P.torchFlicker;
    group.add(light);
  }
  el.setObject3D('mesh', group);
}

function buildRays(){
  const el = document.getElementById('rays');
  clearChildren(el);
  const group = new THREE.Group();
  const b = getBounds();
  const W = b.W, L = b.L, H = b.H;
  const mat = new THREE.MeshBasicMaterial({color:'#fff5e0', transparent:true, opacity:P.godRayIntensity*0.25, side:THREE.DoubleSide, depthWrite:false});
  for(let i=0;i<P.godRayCount;i++){
    const g = new THREE.CylinderGeometry(P.godRayWidth*0.1, P.godRayWidth, H*1.5, 8, 1, true);
    const m = new THREE.Mesh(g, mat);
    m.position.set(lerp(-L/2*0.6, L/2*0.6, i/Math.max(1,P.godRayCount-1)), H*0.7, lerp(-W/2*0.3, W/2*0.3, srand()));
    m.rotation.z = 0.15;
    group.add(m);
  }
  el.setObject3D('mesh', group);
}

function buildParticles(){
  const el = document.getElementById('particles');
  clearChildren(el);
  const N = Math.floor(P.dustDensity);
  if (N<=0) return;
  const b = getBounds();
  const positions = new Float32Array(N*3);
  for(let i=0;i<N;i++){
    positions[i*3]   = (Math.random()-0.5)*b.W*1.2;
    positions[i*3+1] = Math.random()*b.H*1.2;
    positions[i*3+2] = (Math.random()-0.5)*b.L*1.2;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const m = new THREE.PointsMaterial({color:0xffeecc, size:P.dustSize, transparent:true, opacity:0.6, sizeAttenuation:true});
  const pts = new THREE.Points(g, m);
  pts.userData.isDust = true;
  el.setObject3D('mesh', pts);
}

function applyLighting(){
  const sun = document.getElementById('sun');
  const amb = document.getElementById('ambient');
  const hemi = document.getElementById('hemi');
  const az = P.sunAzimuth * Math.PI/180;
  const el = P.sunElevation * Math.PI/180;
  const r = 30;
  sun.setAttribute('position', `${r*Math.cos(el)*Math.cos(az)} ${r*Math.sin(el)} ${r*Math.cos(el)*Math.sin(az)}`);
  sun.setAttribute('light', `type:directional;intensity:${P.sunIntensity};color:${P.sunColor};castShadow:true;shadowMapHeight:2048;shadowMapWidth:2048;shadowBias:-0.0005`);
  amb.setAttribute('light', `type:ambient;intensity:${P.ambientLevel};color:${P.ambientColor}`);
  hemi.setAttribute('light', `type:hemisphere;intensity:${P.hemiIntensity};color:${P.hemiSky};groundColor:${P.hemiGround}`);
}

function applyAtmosphere(){
  const scene = document.querySelector('a-scene');
  scene.setAttribute('fog', `type:exponential;color:${P.fogColor};density:${P.fogDensity}`);
  document.getElementById('sky').setAttribute('color', P.skyTop);
}

function applyCamera(){
  const rig = document.getElementById('rig');
  const pos = rig.getAttribute('position');
  rig.setAttribute('position', `${pos.x} ${P.eyeHeight} ${pos.z}`);
  rig.setAttribute('movement-controls', `speed:${P.walkSpeed};fly:${P.locomotion==='fly'}`);
  const cam = rig.querySelector('[camera]');
  cam.setAttribute('camera', `fov:${P.fov}`);
}

function applyModelTint() {
  if (!loadedModel) return;
  const tint = new THREE.Color(P.modelTint);
  for (const m of modelMaterials) {
    const orig = originalMatProps.get(m);
    if (orig && orig.color && m.color) {
      m.color.copy(orig.color).multiply(tint);
    }
    if ('roughness' in m && orig) m.roughness = clamp(orig.roughness + P.modelRoughBias + P.masterDecay*0.3, 0, 1);
    if ('metalness' in m && orig) m.metalness = clamp(orig.metalness + P.modelMetalBias - P.erosion*0.2, 0, 1);
    if (m.emissive && orig.emissive) m.emissive.copy(orig.emissive).addScalar(P.modelEmissive);
    if ('envMapIntensity' in m) m.envMapIntensity = P.envIntensity;
    m.needsUpdate = true;
  }
}

function applyTransform() {
  if (!loadedModel) return;
  const fit = P.modelAutoFit ? autoFitScale : 1;
  loadedModel.scale.setScalar(fit * P.modelScale);
  loadedModel.rotation.y = P.modelRotY * Math.PI/180;
  modelBounds = new THREE.Box3().setFromObject(loadedModel);
  const c = modelBounds.getCenter(new THREE.Vector3());
  const el = document.getElementById('loaded-model');
  el.object3D.position.set(-c.x, -modelBounds.min.y + P.modelPosY, -c.z);
  modelBounds = new THREE.Box3().setFromObject(el.object3D);
  // visibility — bounds still computed (procedural hall sizes off them) but model is hidden
  el.object3D.visible = P.modelVisible;
}

function applyExposure() {
  const sceneEl = document.querySelector('a-scene');
  if (sceneEl.renderer) sceneEl.renderer.toneMappingExposure = P.exposure;
}

function rebuildAll(){
  reseed(P.seed);
  applyWallDeform();
  buildWater(); buildProps(); buildVeg(); buildTorches(); buildRays(); buildParticles();
  applyLighting(); applyAtmosphere(); applyCamera();
  applyTransform(); applyModelTint(); applyExposure();
  updateStat();
}

function updateStat(){
  const scene = document.querySelector('a-scene');
  let count = 0;
  scene.object3D.traverse(o=>{ if(o.isMesh) count++; });
  const sz = modelBounds ? modelBounds.getSize(new THREE.Vector3()) : null;
  const modelInfo = loadedModel
    ? `model: ${sz.x.toFixed(1)}×${sz.y.toFixed(1)}×${sz.z.toFixed(1)}m, ${modelMaterials.length} mats · `
    : 'no model · ';
  document.getElementById('stat').textContent =
    modelInfo + `params: ${Object.keys(P).length} | meshes: ${count} | seed: ${P.seed}`;
}

// --- SLIDER UI ---
const SCHEMA = [
  ['Model', [
    ['modelVisible','bool'], ['modelAutoFit','bool'], ['fitToHall','range',2,40,0.5],
    ['modelScale','range',0.01,10,0.01], ['modelRotY','range',-180,180,1],
    ['modelPosY','range',-5,10,0.05], ['modelShadows','bool'],
    ['modelTint','color'], ['modelRoughBias','range',-1,1,0.01],
    ['modelMetalBias','range',-1,1,0.01], ['modelEmissive','range',0,1,0.01],
  ]],
  ['Loaded Walls (deforms glb walls)', [
    ['wallPattern','select',['wall','wall|panel|partition','wall|side','^Wall_','.*']],
    ['wallSegments','range',1,40,1],
    ['wallHeight','range',0.3,3,0.01], ['wallThickness','range',0.3,3,0.01],
    ['wallBow','range',-2,2,0.02], ['wallTilt','range',-1,1,0.02],
    ['wallTopJag','range',0,1,0.01],
  ]],
  ['Water', [
    ['waterEnabled','bool'], ['waterLevel','range',-3,5,0.05], ['waterColor','color'],
    ['waterMurk','range',0,1,0.01], ['waterWaveAmp','range',0,0.5,0.01],
    ['waterWaveFreq','range',0.1,5,0.1], ['waterReflect','range',0,1,0.01],
    ['waterFoam','range',0,1,0.01], ['waterPadFactor','range',1,3,0.05],
  ]],
  ['Lighting', [
    ['sunAzimuth','range',0,360,1], ['sunElevation','range',-10,90,1],
    ['sunIntensity','range',0,5,0.05], ['sunColor','color'],
    ['ambientLevel','range',0,2,0.01], ['ambientColor','color'],
    ['hemiIntensity','range',0,2,0.01], ['hemiSky','color'], ['hemiGround','color'],
    ['envIntensity','range',0,3,0.01],
    ['envPreset','select',['studio','sunset','overcast','night','cave']],
    ['godRayCount','range',0,12,1], ['godRayIntensity','range',0,2,0.05],
    ['godRayWidth','range',0.1,2,0.05], ['torchCount','range',0,16,1],
    ['torchColor','color'], ['torchIntensity','range',0,5,0.05],
    ['torchFlicker','range',0,2,0.05], ['shadowSoft','range',0,5,0.1],
  ]],
  ['Atmosphere', [
    ['fogDensity','range',0,0.3,0.001], ['fogColor','color'],
    ['fogHeightFalloff','range',0,2,0.01], ['dustDensity','range',0,2000,10],
    ['dustSize','range',0.01,0.5,0.01], ['dustDrift','range',0,2,0.01],
    ['bloomStrength','range',0,2,0.05],
  ]],
  ['Sky / Environment', [
    ['skyMode','select',['gradient','day','sunset','night','storm']],
    ['skyTop','color'], ['skyBottom','color'], ['timeOfDay','range',0,1,0.01],
    ['beyondWalls','select',['forest','desert','ocean','void','mountain']],
  ]],
  ['Vegetation', [
    ['vineDensity','range',0,1,0.01], ['vineLength','range',0.3,4,0.1],
    ['vineSway','range',0,2,0.01], ['mossSpecies','select',['lichen','moss','algae','none']],
    ['mossHue','color'], ['floorPlants','range',0,1,0.01],
    ['floatingLeaves','range',0,1,0.01], ['flowerDensity','range',0,1,0.01],
    ['flowerColor','color'],
  ]],
  ['Props', [
    ['statueCount','range',0,8,1], ['statueStyle','select',['humanoid','beast','abstract']],
    ['statueDamage','range',0,1,0.01], ['altar','bool'], ['sarcCount','range',0,4,1],
    ['rubbleDensity','range',0,2,0.01], ['columnPieces','range',0,12,1],
    ['potteryDensity','range',0,1,0.01], ['brazierCount','range',0,12,1],
    ['bannerCount','range',0,8,1], ['bannerColor','color'],
  ]],
  ['Decay (applied to model)', [
    ['masterDecay','range',0,1,0.01], ['crackDensity','range',0,1,0.01],
    ['erosion','range',0,1,0.01], ['colorFade','range',0,1,0.01], ['bioGrowth','range',0,1,0.01],
  ]],
  ['Post-processing', [
    ['postFxEnabled','bool'], ['fxaa','bool'],
    ['exposure','range',0.1,3,0.01], ['contrast','range',0.5,2,0.01],
    ['saturation','range',0,2,0.01], ['tint','color'], ['vignette','range',0,1,0.01],
    ['bloomStrength','range',0,3,0.01], ['bloomThreshold','range',0,2,0.01], ['bloomRadius','range',0.3,3,0.05],
    ['tonemapping','select',['aces','reinhard','cineon','linear','none']],
  ]],
  ['Camera / Participant', [
    ['walkSpeed','range',0.05,1,0.01], ['fov','range',40,120,1],
    ['eyeHeight','range',0.5,3,0.05], ['headBob','range',0,1,0.01],
    ['locomotion','select',['smooth','teleport','fly','fixed']],
  ]],
  ['Time / Dynamics', [
    ['dayNightSpeed','range',0,1,0.01], ['waterRiseRate','range',-0.1,0.1,0.005],
    ['vegGrowthRate','range',0,1,0.01], ['windStrength','range',0,2,0.01],
  ]],
  ['VR / Interaction', [
    ['physics','bool'], ['handModel','select',['none','ghost','realistic']],
    ['vrComfort','range',0,1,0.01], ['ipdOffset','range',-0.02,0.02,0.001],
  ]],
  ['Experiment', [
    ['seed','range',1,9999,1], ['trialDuration','range',5,600,5],
    ['stimDelay','range',0,30,0.5], ['fixationVisible','bool'],
    ['variantLabel','bool'], ['showStats','bool'],
  ]],
];

let dirtyTimer = null;
function markDirty(){
  clearTimeout(dirtyTimer);
  dirtyTimer = setTimeout(rebuildAll, 80);
}

const WALL_DEFORM_KEYS = new Set(['wallHeight','wallThickness','wallBow','wallTilt','wallTopJag']);
const WALL_REDETECT_KEYS = new Set(['wallSegments','wallPattern']);

function fastApply(key){
  if (WALL_REDETECT_KEYS.has(key)) { detectWalls(); applyWallDeform(); return; }
  if (WALL_DEFORM_KEYS.has(key))   { applyWallDeform(); return; }
  if (['sunAzimuth','sunElevation','sunIntensity','sunColor','ambientLevel','ambientColor','hemiIntensity','hemiSky','hemiGround'].includes(key)) { applyLighting(); return; }
  if (['envPreset','envIntensity'].includes(key)) { regenerateEnv(); applyModelTint(); return; }
  if (['fogDensity','fogColor','skyTop'].includes(key)) { applyAtmosphere(); return; }
  if (['walkSpeed','fov','eyeHeight','locomotion'].includes(key)) { applyCamera(); return; }
  if (['exposure','tonemapping'].includes(key)) { configureRenderer(); return; }
  if (['modelRotY','modelScale','modelPosY','modelTint','modelRoughBias','modelMetalBias','modelEmissive','modelVisible'].includes(key)) {
    applyTransform(); applyModelTint(); return;
  }
  markDirty();
}

function makeRow(key, type, args) {
  const row = document.createElement('div'); row.className='row';
  const lbl = document.createElement('label'); lbl.textContent = key; row.appendChild(lbl);
  if (type==='range'){
    const [min,max,step] = args;
    const inp = document.createElement('input'); inp.type='range'; inp.min=min; inp.max=max; inp.step=step; inp.value=P[key];
    const num = document.createElement('input'); num.type='number'; num.min=min; num.max=max; num.step=step; num.value=P[key];
    inp.addEventListener('input', ()=>{ P[key]=+inp.value; num.value=inp.value; fastApply(key); });
    num.addEventListener('change', ()=>{ P[key]=+num.value; inp.value=num.value; fastApply(key); });
    row.appendChild(inp); row.appendChild(num);
  } else if (type==='color'){
    const inp = document.createElement('input'); inp.type='color'; inp.value=P[key];
    inp.addEventListener('input', ()=>{ P[key]=inp.value; fastApply(key); });
    row.appendChild(inp);
  } else if (type==='bool'){
    const inp = document.createElement('input'); inp.type='checkbox'; inp.checked=!!P[key];
    inp.addEventListener('change', ()=>{ P[key]=inp.checked; markDirty(); });
    row.appendChild(inp);
  } else if (type==='select'){
    const opts = args[0];
    const sel = document.createElement('select');
    for (const o of opts){ const op=document.createElement('option'); op.value=o; op.textContent=o; if (P[key]===o) op.selected=true; sel.appendChild(op); }
    sel.addEventListener('change', ()=>{ P[key]=sel.value; fastApply(key); });
    row.appendChild(sel);
  }
  return row;
}

function buildPanel(){
  const root = document.getElementById('controls');
  root.innerHTML = '';
  for (const [cat, items] of SCHEMA){
    const det = document.createElement('details');
    if (['Model','Lighting','Water','Post-processing'].includes(cat)) det.open = true;
    const sum = document.createElement('summary'); sum.textContent = cat;
    det.appendChild(sum);
    for (const item of items){
      const [key, type, ...args] = item;
      det.appendChild(makeRow(key, type, args));
    }
    root.appendChild(det);
  }
  buildMaterialPanel();
}

function buildMaterialPanel() {
  const root = document.getElementById('controls');
  const existing = document.getElementById('mat-section');
  if (existing) existing.remove();
  if (modelMaterials.length === 0) return;
  const det = document.createElement('details');
  det.id = 'mat-section';
  det.open = true;
  det.style.background = '#0c1018';
  det.style.borderTop = '2px solid #5af';
  det.style.borderBottom = '2px solid #5af';
  const sum = document.createElement('summary');
  sum.textContent = `★ Loaded Model Materials (${modelMaterials.length}) — change these to edit the dropped glb`;
  sum.style.color = '#9cf';
  det.appendChild(sum);
  modelMaterials.forEach((m, idx) => {
    const name = m.name || `mat_${idx}`;
    const head = document.createElement('div'); head.className='row';
    head.style.background = '#0e131c';
    head.innerHTML = `<label style="flex:1;color:#9cf;font-weight:600;font-size:11px">${name}</label>`;
    det.appendChild(head);
    if (m.color) {
      const row = document.createElement('div'); row.className='row';
      const lbl = document.createElement('label'); lbl.textContent='color'; row.appendChild(lbl);
      const inp = document.createElement('input'); inp.type='color';
      inp.value = '#'+m.color.getHexString();
      inp.addEventListener('input', ()=>{ m.color.set(inp.value); m.needsUpdate=true; });
      row.appendChild(inp);
      det.appendChild(row);
    }
    if ('roughness' in m) {
      const row = document.createElement('div'); row.className='row';
      const lbl = document.createElement('label'); lbl.textContent='roughness'; row.appendChild(lbl);
      const inp = document.createElement('input'); inp.type='range'; inp.min=0; inp.max=1; inp.step=0.01; inp.value=m.roughness;
      const num = document.createElement('input'); num.type='number'; num.min=0; num.max=1; num.step=0.01; num.value=m.roughness;
      inp.addEventListener('input', ()=>{ m.roughness=+inp.value; num.value=inp.value; m.needsUpdate=true; });
      num.addEventListener('change', ()=>{ m.roughness=+num.value; inp.value=num.value; m.needsUpdate=true; });
      row.appendChild(inp); row.appendChild(num);
      det.appendChild(row);
    }
    if ('metalness' in m) {
      const row = document.createElement('div'); row.className='row';
      const lbl = document.createElement('label'); lbl.textContent='metalness'; row.appendChild(lbl);
      const inp = document.createElement('input'); inp.type='range'; inp.min=0; inp.max=1; inp.step=0.01; inp.value=m.metalness;
      const num = document.createElement('input'); num.type='number'; num.min=0; num.max=1; num.step=0.01; num.value=m.metalness;
      inp.addEventListener('input', ()=>{ m.metalness=+inp.value; num.value=inp.value; m.needsUpdate=true; });
      num.addEventListener('change', ()=>{ m.metalness=+num.value; inp.value=num.value; m.needsUpdate=true; });
      row.appendChild(inp); row.appendChild(num);
      det.appendChild(row);
    }
    if (m.emissive) {
      const row = document.createElement('div'); row.className='row';
      const lbl = document.createElement('label'); lbl.textContent='emissive'; row.appendChild(lbl);
      const inp = document.createElement('input'); inp.type='color';
      inp.value = '#'+m.emissive.getHexString();
      inp.addEventListener('input', ()=>{ m.emissive.set(inp.value); m.needsUpdate=true; });
      row.appendChild(inp);
      det.appendChild(row);
    }
  });
  // INSERT AT TOP of controls, not bottom
  root.insertBefore(det, root.firstChild);
}

// --- buttons ---
document.getElementById('btn-rebuild').onclick = rebuildAll;
document.getElementById('btn-randomize').onclick = ()=>{
  P.seed = Math.floor(Math.random()*9999);
  P.fogDensity = Math.random()*0.05;
  P.sunAzimuth = Math.random()*360;
  P.sunElevation = 10 + Math.random()*50;
  P.envPreset = ['studio','sunset','overcast','night','cave'][Math.floor(Math.random()*5)];
  P.skyTop = '#'+Math.floor(Math.random()*0xffffff).toString(16).padStart(6,'0');
  P.fogColor = P.skyTop;
  P.waterMurk = Math.random();
  P.dustDensity = Math.floor(Math.random()*800);
  P.vineDensity = Math.random()*0.7;
  P.torchCount = Math.floor(Math.random()*8);
  buildPanel();
  regenerateEnv();
  rebuildAll();
};
document.getElementById('btn-export').onclick = ()=>{
  const blob = new Blob([JSON.stringify(P,null,2)], {type:'application/json'});
  const a = document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download = `glb_preset_${P.seed}.json`; a.click();
};
document.getElementById('btn-import').onclick = ()=> document.getElementById('file-import').click();
document.getElementById('file-import').onchange = (e)=>{
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = ()=>{
    try { Object.assign(P, JSON.parse(r.result));
      buildPanel(); regenerateEnv(); rebuildAll();
    } catch(err){ alert('Bad JSON: '+err.message); }
  };
  r.readAsText(f);
};
document.getElementById('btn-load-glb').onclick = ()=> document.getElementById('file-glb').click();
document.getElementById('file-glb').onchange = (e)=>{
  const f = e.target.files[0]; if (f) loadGLBFile(f);
};
document.getElementById('btn-clear').onclick = clearModel;

// --- drag and drop ---
const drop = document.getElementById('drop');
['dragenter','dragover'].forEach(ev => document.addEventListener(ev, e => {
  e.preventDefault(); drop.classList.add('show');
}));
['dragleave','drop'].forEach(ev => document.addEventListener(ev, e => {
  if (ev === 'dragleave' && e.relatedTarget) return;
  drop.classList.remove('show');
}));
document.addEventListener('drop', e => {
  e.preventDefault();
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (!f) return;
  if (!/\.(glb|gltf)$/i.test(f.name)) {
    alert('Drop a .glb or .gltf file. Got: '+f.name);
    return;
  }
  loadGLBFile(f);
});

// --- keyboard: P to toggle panel ---
window.addEventListener('keydown', (e)=>{
  if (e.target && /input|select|textarea/i.test(e.target.tagName)) return;
  if (e.key==='p' || e.key==='P'){
    const p = document.getElementById('panel');
    p.style.display = p.style.display==='none' ? 'block' : 'none';
    document.querySelector('a-scene').style.marginRight = p.style.display==='none' ? '0' : '360px';
    window.dispatchEvent(new Event('resize'));
  }
});

// --- animation tick ---
let _t = 0;
AFRAME.registerComponent('global-tick', {
  tick: function(t, dt){
    _t = t/1000;
    const dust = document.getElementById('particles').getObject3D('mesh');
    if (dust && dust.isPoints){
      const pos = dust.geometry.attributes.position;
      const b = getBounds();
      for(let i=0;i<pos.count;i++){
        pos.setY(i, pos.getY(i) - dt*0.0002*P.dustDrift);
        if (pos.getY(i) < 0) pos.setY(i, b.H*1.1);
      }
      pos.needsUpdate = true;
    }
    document.getElementById('torches').object3D.traverse(o=>{
      if (o.isPointLight && o.userData.flicker){
        o.intensity = o.userData.baseIntensity * (1 + Math.sin(_t*15 + o.position.x)*0.2*o.userData.flicker);
      }
    });
    document.getElementById('props').object3D.traverse(o=>{
      if (o.userData && o.userData.flicker && o.scale){
        o.scale.y = 1 + Math.sin(_t*12 + o.position.x*3)*0.15;
      }
    });
    const w = document.getElementById('water').getObject3D('mesh');
    if (w && w.geometry && P.waterEnabled){
      const pos = w.geometry.attributes.position;
      for(let i=0;i<pos.count;i++){
        const x = pos.getX(i), y = pos.getY(i);
        pos.setZ(i, Math.sin(_t*P.waterWaveFreq + x*0.5 + y*0.3)*P.waterWaveAmp);
      }
      pos.needsUpdate = true;
      w.geometry.computeVertexNormals();
    }
    if (P.waterRiseRate !== 0){
      P.waterLevel = clamp(P.waterLevel + P.waterRiseRate*dt*0.001, -3, 5);
      if (w) w.position.y = P.waterLevel;
    }
    if (P.dayNightSpeed > 0){
      P.sunElevation = (P.sunElevation + dt*0.01*P.dayNightSpeed) % 90;
      applyLighting();
    }
    document.getElementById('veg').object3D.traverse(o=>{
      if (o.userData && o.userData.sway){
        o.rotation.z = Math.sin(_t*1.5 + o.position.x)*o.userData.sway*0.3*P.windStrength;
      }
    });
  }
});

// --- kick off ---
buildPanel();
const sceneEl = document.querySelector('a-scene');
function boot() {
  configureRenderer();
  regenerateEnv();
  setupPostFx();
  sceneEl.setAttribute('global-tick','');
  rebuildAll();
  // auto-load via ?model=path.glb query param
  const params = new URLSearchParams(location.search);
  const modelUrl = params.get('model');
  if (modelUrl) loadGLBFromUrl(modelUrl, modelUrl.split('/').pop());
}
sceneEl.addEventListener('loaded', boot);
if (sceneEl.hasLoaded) boot();
